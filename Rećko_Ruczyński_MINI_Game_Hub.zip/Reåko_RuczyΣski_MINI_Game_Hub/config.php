<?php
	
	// set the database connection info
	define("DB_SERVER", "localhost");
	define("DB_USER", "ruczynskih");
	define("DB_PASSWD", "vah3Bive");
	define("DB_NAME", "ruczynskih");

	// define the some extra stuff
	define("SITE_ADDR", ".");

?>